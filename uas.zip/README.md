## Anggota Kelompok
- Chrealvin (00000045606)
- Tristan Liandra Amatya (00000089615)
- Bisara Wahyu Diwangga (00000063627)
- Stephen Tanuwijaya (00000042628)

## Cara memainkan permainan
klik tulang untuk mengambil tulang
Setiap kali tulang diambil, terdapat kemungkinan spike akan bangun
Orang yang membangunkan spike pertama kali kalah

## other stuff...
- project ini menggunakan react typescript
- link github uas dapat diakses di https://github.com/chrezalvin/pti-uas
- npm i terlebih dahulu sebelum run app
- npm start untuk run app (just in case)
- semua gambar dan audio terdapat di /src/assets
- semua component terdapat di /src/Components
- semua Pages terdapat di /src/Pages

